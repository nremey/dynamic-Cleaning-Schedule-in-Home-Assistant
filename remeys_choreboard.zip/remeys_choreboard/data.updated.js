window.TABLE_DATA = [
  {
    "__uid": "mlrv613r",
    "Area": "Sample Tasks",
    "Task": "Welcome! These tasks are prefilled to guide you on first use.",
    "Assignee": "",
    "Notes": "",
    "Rhythmen": 1,
    "RhythmUnit": "d",
    "MonthMask": 4095,
    "WeekMask": 127,
    "EntityConnector": {
      "enabled": false
    },
    "Icon": "mdi:human-welcome",
    "Last done [Date]": "2026-01-01",
    "Last done [By]": "Remey",
    "New Due date [date]": "2026-02-28",
    "Due in [days]": 10,
    "__history": [
      "2026-01-01"
    ],
    "__history_doneby": []
  },
  {
    "__uid": "mlrv613s",
    "Area": "Sample Tasks",
    "Task": "Try it out: complete, edit, or delete this sample task.",
    "Assignee": "all",
    "Notes": "",
    "Rhythmen": 1,
    "RhythmUnit": "w",
    "MonthMask": 4095,
    "WeekMask": 127,
    "EntityConnector": {
      "enabled": false
    },
    "Icon": "",
    "Last done [Date]": "2026-01-01",
    "Last done [By]": "Remey",
    "New Due date [date]": "2026-02-28",
    "Due in [days]": 10,
    "__history": [
      "2026-02-18"
    ],
    "__history_doneby": []
  },
  {
    "__uid": "mlrv613t",
    "Area": "Getting Started",
    "Task": "Step 1: Open the menu and set up users (optional).",
    "Assignee": "",
    "Notes": "",
    "Rhythmen": 7,
    "RhythmUnit": "d",
    "MonthMask": 4095,
    "WeekMask": 127,
    "EntityConnector": {
      "enabled": false
    },
    "Icon": "gis:step",
    "Last done [Date]": "2026-02-01",
    "Last done [By]": "Remey",
    "New Due date [date]": "2026-02-28",
    "Due in [days]": 10,
    "__history": [
      "2026-02-01"
    ],
    "__history_doneby": []
  },
  {
    "__uid": "mlrv613u",
    "Area": "Getting Started",
    "Task": "Step 2: In the menu, enable the sections you want (for example Notes and Calendar).",
    "Assignee": "",
    "Notes": "For each Home Assistant user, you can define which Choreboard users are shown.\nExample: a family account can show all members.\nA shared parent account can show only parent members.",
    "Rhythmen": 7,
    "RhythmUnit": "d",
    "MonthMask": 4095,
    "WeekMask": 127,
    "EntityConnector": {
      "enabled": false
    },
    "Icon": "gis:step",
    "Last done [Date]": "2026-02-02",
    "Last done [By]": "Remey",
    "New Due date [date]": "2026-02-28",
    "Due in [days]": 10,
    "__history": [
      "2026-02-02"
    ],
    "__history_doneby": []
  },
  {
    "__uid": "mlrv613v",
    "Area": "Getting Started",
    "Task": "Step 3: Create your own tasks and adjust these samples as needed.",
    "Assignee": "",
    "Notes": "",
    "Rhythmen": 7,
    "RhythmUnit": "d",
    "MonthMask": 4095,
    "WeekMask": 127,
    "EntityConnector": {
      "enabled": false
    },
    "Icon": "gis:step",
    "Last done [Date]": "2026-02-03",
    "Last done [By]": "Remey",
    "New Due date [date]": "2026-02-28",
    "Due in [days]": 10,
    "__history": [
      "2026-02-03"
    ],
    "__history_doneby": []
  },
  {
    "__uid": "mlrv613w",
    "Area": "Getting Started",
    "Task": "Step 4: Customize the display per user (theme colors, gauge style, week start Mon/Sun).",
    "Assignee": "",
    "Notes": "",
    "Rhythmen": 7,
    "RhythmUnit": "d",
    "MonthMask": 4095,
    "WeekMask": 127,
    "EntityConnector": {
      "enabled": false
    },
    "Icon": "gis:step",
    "Last done [Date]": "2026-02-04",
    "Last done [By]": "Remey",
    "New Due date [date]": "2026-02-28",
    "Due in [days]": 10,
    "__history": [
      "2026-02-04"
    ],
    "__history_doneby": []
  },
  {
    "__uid": "mlrw0hup",
    "Area": "Getting Started",
    "Task": "Step 5: Try different views, date ranges, and sorting in the header. Filter settings are saved per user and switch automatically with the selected user.",
    "Assignee": "",
    "Notes": "",
    "Rhythmen": 7,
    "RhythmUnit": "d",
    "MonthMask": 4095,
    "WeekMask": 127,
    "EntityConnector": {
      "enabled": false
    },
    "Icon": "",
    "Last done [Date]": "2026-02-05",
    "Last done [By]": "Remey",
    "New Due date [date]": "2026-02-28",
    "Due in [days]": 10,
    "__history": [
      "2026-02-05"
    ],
    "__history_doneby": []
  },
  {
    "__uid": "mlrws3xk",
    "Area": "Sample Tasks",
    "Task": "With all the chores on your list, don't forget to treat yourself to something nice, too.",
    "Assignee": "",
    "Notes": "",
    "Rhythmen": 1,
    "RhythmUnit": "w",
    "MonthMask": 4095,
    "WeekMask": 127,
    "EntityConnector": {
      "enabled": false
    },
    "Icon": "material-symbols:digital-wellbeing",
    "Last done [Date]": "2026-01-01",
    "Last done [By]": "Remey",
    "New Due date [date]": "2026-01-08",
    "Due in [days]": -41,
    "__history": [
      "2026-01-01"
    ],
    "__history_doneby": []
  }
];
