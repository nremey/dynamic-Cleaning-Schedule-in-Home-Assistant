# Remeys Choreboard (HTML + Home Assistant)

This HTML file is **not usable without Home Assistant configuration**.

For export/webhook features to work, the YAML parts must be added **manually** in Home Assistant.

## 1) Manually add YAML in Home Assistant

### `configuration.yaml`

```yaml
shell_command:
  putzplan_textcontentfile_save: >-
    sh -c 'dir="{{ path }}";
    file="$dir/{{ filename }}";
    mkdir -p "$dir";
    echo "{{ content_b64 }}" | base64 -d > "$file"'
```

### `automations.yaml`

```yaml
- alias: "Webhook: Remeys Choreboard putzplan_file_export"
  trigger:
    - platform: webhook
      webhook_id: putzplan_textcontentfile_export
  action:
    - service: shell_command.putzplan_textcontentfile_save
      data:
        path: "{{ trigger.json.savingpath }}"
        filename: "{{ trigger.json.filename }}"
        content_b64: "{{ trigger.json.content_b64 }}"
```

Important:
- `webhook_id` must match the ID used in the HTML file.
- The `shell_command` name and service call must match exactly.
- After changes: validate configuration and restart Home Assistant.

## 2) Embed the HTML file in Home Assistant via Iframe

1. Place the HTML file inside your HA config area (for example `/config/www/...`).
2. Copy the file path.
3. In Lovelace URLs: **`/config` becomes `/local`**.

Example:
- File path on system: `/config/www/remeys_choreboard/index_taskboard.html`
- URL in Home Assistant: `/local/remeys_choreboard/index_taskboard.html`

### Example iframe card

```yaml
type: iframe
url: /local/remeys_choreboard/index_taskboard.html
aspect_ratio: 75%
```

Without the steps above, the HTML file is not useful (especially export/webhook will not work).
