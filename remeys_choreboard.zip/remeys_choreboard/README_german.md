# Remeys Choreboard (HTML + Home Assistant)

Diese HTML-Datei ist **ohne Home-Assistant-Konfiguration nicht nutzbar**.

Damit Export/Webhook funktioniert, müssen YAML-Teile **manuell** in Home Assistant eingetragen werden.

## 1) YAML manuell in Home Assistant einfügen

### `configuration.yaml`

```yaml
shell_command:
  putzplan_textcontentfile_save: >-
    sh -c 'dir="{{ path }}";
    file="$dir/{{ filename }}";
    mkdir -p "$dir";
    echo "{{ content_b64 }}" | base64 -d > "$file"'
```

### `automations.yaml`

```yaml
- alias: "Webhook: Remeys Choreboard putzplan_file_export"
  trigger:
    - platform: webhook
      webhook_id: putzplan_textcontentfile_export
  action:
    - service: shell_command.putzplan_textcontentfile_save
      data:
        path: "{{ trigger.json.savingpath }}"
        filename: "{{ trigger.json.filename }}"
        content_b64: "{{ trigger.json.content_b64 }}"
```

Wichtig:
- `webhook_id` muss zur ID in der HTML-Datei passen. Daher am besten nicht ändern.
- `shell_command`-Name und Service-Aufruf müssen identisch sein.
- Nach Änderungen: Konfiguration prüfen und Home Assistant neu starten.

## 2) HTML-Datei in Home Assistant per Iframe einbetten

1. Den Ordner und die HTML-Datei in deinem HA-Config-Bereich ablegen (z. B. unter `/config/www/...`).
2. Dateipfad kopieren.
3. Für Lovelace-URLs gilt: **`/config` wird zu `/local`**.

Beispiel:
- Dateipfad im System: `/config/www/remeys_choreboard/index_taskboard.html`
- URL in Home Assistant: `/local/remeys_choreboard/index_taskboard.html`

### Beispiel-Iframe-Card

```yaml
type: iframe
url: /local/remeys_choreboard/index_taskboard.html
aspect_ratio: 75%
```

Ohne die Schritte oben ist die HTML-Datei nicht sinnvoll verwendbar (insbesondere Export/Webhook).
